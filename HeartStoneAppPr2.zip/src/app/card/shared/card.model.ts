export interface CardDeck{
    name: string;
    types: string[];
}